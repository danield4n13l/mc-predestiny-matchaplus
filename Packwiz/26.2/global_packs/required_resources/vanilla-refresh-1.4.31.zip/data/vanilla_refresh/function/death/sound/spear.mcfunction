
playsound minecraft:item.spear.hit player @p ~ ~ ~ .4 1
playsound minecraft:item.spear.attack player @p ~ ~ ~ .4 1
