playsound minecraft:entity.ender_dragon.ambient player @p ~ ~ ~ .3 1
tag @s add refresh_temp16