
playsound minecraft:entity.player.big_fall player @p ~ ~ ~ 1 1

playsound minecraft:entity.player.big_fall player @p ~ ~ ~ .5 .5

playsound minecraft:block.calcite.break player @p ~ ~ ~ 2 1.2
playsound minecraft:block.netherrack.break player @a[distance=..16] ~ ~ ~ 2 .5



tag @s add refresh_temp16
